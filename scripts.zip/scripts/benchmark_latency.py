"""
benchmark_latency.py
====================
Reproduce Table VIII (Computational Complexity & Inference Latency) from the
Detector paper.  Measures wall-clock inference latency for all four system
configurations:

  1. Full Detector   (BiLSTM + XGBoost meta, full pipeline)
  2. BiLSTM-15s      (standalone BiLSTM, 15 s window)
  3. XGBoost-only    (tabular path, no BiLSTM)
  4. BERT-WP         (BERT-based word-piece baseline)

Protocol (mirrors outputs/complexity_benchmark_v3_15m/s.json):
  - 100 GPU warm-up inference passes (discarded)
  - 1000 timed inference passes
  - batch_size = 1 (online/single-sample mode)
  - GPU synchronization between every pass
  - Seed = 42

Usage
-----
  # Full benchmark (both speeds, saves JSON to outputs/latency/):
  python benchmark_latency.py

  # One speed only:
  python benchmark_latency.py --speed 15

  # CPU-only mode (results will not match paper GPU numbers):
  python benchmark_latency.py --cpu

Prerequisites
-------------
  - Trained model weights in outputs/models_{speed}ms/
    (produced by running Detector_15ms_FINAL.ipynb / Detector_25ms_FINAL.ipynb)
  - Preprocessed arrays in outputs/preprocessed/
    (produced by running: python preprocess.py)

Output
------
  outputs/latency/
    latency_15ms.json
    latency_25ms.json
    latency_summary.json
"""

import os, json, time, argparse, tracemalloc
from pathlib import Path
from datetime import datetime, timezone

import numpy as np

# ── Optional GPU imports (fail gracefully for CPU-only runs) ──────────────────
try:
    import tensorflow as tf
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import xgboost as xgb
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False


# ── Benchmark protocol constants ──────────────────────────────────────────────
N_WARMUP   = 100
N_RUNS     = 1000
BATCH_SIZE = 1
BENCH_SEED = 42


def _sync_gpu():
    """Synchronize GPU to get accurate wall-clock latency."""
    if TORCH_AVAILABLE and torch.cuda.is_available():
        torch.cuda.synchronize()
    if TF_AVAILABLE:
        tf.constant(0.0).numpy()   # forces TF to flush pending kernels


def _timed_runs(inference_fn, dummy_input, n_warmup=N_WARMUP, n_runs=N_RUNS):
    """Run inference_fn(dummy_input) n_warmup + n_runs times; return stats."""
    # warm-up
    for _ in range(n_warmup):
        inference_fn(dummy_input)
        _sync_gpu()

    latencies = []
    for _ in range(n_runs):
        _sync_gpu()
        t0 = time.perf_counter()
        inference_fn(dummy_input)
        _sync_gpu()
        latencies.append((time.perf_counter() - t0) * 1000.0)  # → ms

    a = np.array(latencies)
    return {
        "mean_ms": float(a.mean()),
        "std_ms":  float(a.std(ddof=1)),
        "p50_ms":  float(np.percentile(a, 50)),
        "p95_ms":  float(np.percentile(a, 95)),
        "p99_ms":  float(np.percentile(a, 99)),
        "min_ms":  float(a.min()),
        "max_ms":  float(a.max()),
        "n_warmup": n_warmup,
        "n_runs":   n_runs,
    }


def _peak_memory_mb(inference_fn, dummy_input):
    """Measure peak CPU RAM usage with tracemalloc."""
    tracemalloc.start()
    inference_fn(dummy_input)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / 1024 / 1024


def benchmark_bilstm(model_path: str, seq_len: int, n_features: int = 5) -> dict:
    """Benchmark a saved Keras/TF BiLSTM model."""
    if not TF_AVAILABLE:
        return {"error": "TensorFlow not available"}
    model = tf.keras.models.load_model(model_path)
    dummy = tf.zeros([BATCH_SIZE, seq_len, n_features])

    latency = _timed_runs(model.predict, dummy)

    # GPU memory
    mem_gpu_mb = 0.0
    try:
        info = tf.config.experimental.get_memory_info("GPU:0")
        mem_gpu_mb = info["peak"] / 1024 / 1024
    except Exception:
        pass

    mem_cpu_mb = _peak_memory_mb(model.predict, dummy)
    return {"latency_ms": latency,
            "memory_mb": {"gpu_peak_mb": mem_gpu_mb, "cpu_peak_mb": mem_cpu_mb},
            "trainable_params_nn": int(model.count_params())}


def benchmark_xgb(model_path: str, tab_dim: int = 35) -> dict:
    """Benchmark a saved XGBoost meta-classifier."""
    if not XGB_AVAILABLE:
        return {"error": "XGBoost not available"}
    booster = xgb.Booster()
    booster.load_model(model_path)
    dummy_np = np.random.default_rng(BENCH_SEED).random((BATCH_SIZE, tab_dim)).astype(np.float32)
    dummy_dm = xgb.DMatrix(dummy_np)

    latency = _timed_runs(booster.predict, dummy_dm)
    mem_cpu_mb = _peak_memory_mb(booster.predict, dummy_dm)
    return {"latency_pure_ms": latency,
            "memory_mb": {"cpu_peak_mb": mem_cpu_mb}}


def run_benchmark(speed: int, outputs_base: Path, out_dir: Path, cpu_only: bool = False) -> dict:
    """Run all four configurations for a given speed and save results."""
    preprocessed_dir = outputs_base / "preprocessed"
    models_dir       = outputs_base / f"models_{speed}ms"

    # Load preprocessed data for a representative test sample
    npz_path = preprocessed_dir / f"windows_{speed}ms_seed42.npz"
    if not npz_path.exists():
        raise FileNotFoundError(
            f"{npz_path} not found. Run 'python preprocess.py --speed {speed} --seed 42' first.")

    d = np.load(npz_path, allow_pickle=True)
    seq_len  = int(d["max_len"])
    tab_dim  = int(d["X_tab_test"].shape[1])

    # Discover model files
    bilstm_path = models_dir / f"bilstm_seed42.keras"     # or .h5
    if not bilstm_path.exists():
        bilstm_path = models_dir / f"bilstm_seed42.h5"

    xgb_path = models_dir / f"meta_xgb_seed42.pkl"

    hardware = {
        "cpu_only": cpu_only,
        "tf_version":    tf.__version__ if TF_AVAILABLE    else "n/a",
        "torch_version": torch.__version__ if TORCH_AVAILABLE else "n/a",
    }
    if TORCH_AVAILABLE and torch.cuda.is_available() and not cpu_only:
        hardware["gpu_name"] = torch.cuda.get_device_name(0)
        hardware["cuda_version"] = torch.version.cuda

    configs = {}

    # 1. BiLSTM standalone
    if bilstm_path.exists():
        print(f"    [BiLSTM-{speed}ms] ", end="", flush=True)
        try:
            configs["bilstm"] = benchmark_bilstm(str(bilstm_path), seq_len)
            print(f"OK  ({configs['bilstm']['latency_ms']['mean_ms']:.1f} ms avg)")
        except Exception as e:
            configs["bilstm"] = {"error": str(e)}
            print(f"FAILED: {e}")
    else:
        configs["bilstm"] = {"error": f"Model not found at {bilstm_path}"}
        print(f"    [BiLSTM-{speed}ms] SKIPPED (model not found)")

    # 2. XGBoost meta-classifier
    if xgb_path.exists():
        print(f"    [XGBoost-{speed}ms] ", end="", flush=True)
        try:
            configs["xgboost"] = benchmark_xgb(str(xgb_path), tab_dim)
            print(f"OK  ({configs['xgboost']['latency_pure_ms']['mean_ms']:.3f} ms avg)")
        except Exception as e:
            configs["xgboost"] = {"error": str(e)}
            print(f"FAILED: {e}")
    else:
        configs["xgboost"] = {"error": f"Model not found at {xgb_path}"}
        print(f"    [XGBoost-{speed}ms] SKIPPED (model not found)")

    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "target_speed": speed,
        "hardware": hardware,
        "protocol": {
            "n_warmup": N_WARMUP,
            "n_timed_runs": N_RUNS,
            "batch_size": BATCH_SIZE,
            "window_seconds": 15,
            "benchmark_seed": BENCH_SEED,
        },
        "configurations": configs,
    }

    fname = f"latency_{speed}ms.json"
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / fname, "w") as fh:
        json.dump(result, fh, indent=2)

    return result


def main():
    parser = argparse.ArgumentParser(description="Reproduce latency benchmarks from Table VIII.")
    parser.add_argument("--speed", type=int, choices=[15, 25], default=None)
    parser.add_argument("--cpu", action="store_true", help="Force CPU-only mode")
    parser.add_argument("--outputs", default="outputs",
                        help="Base outputs directory (default: outputs)")
    parser.add_argument("--out", default="outputs/latency",
                        help="Output directory (default: outputs/latency)")
    args = parser.parse_args()

    if args.cpu and TF_AVAILABLE:
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

    speeds = [args.speed] if args.speed else [15, 25]
    outputs_base = Path(args.outputs)
    out_dir = Path(args.out)

    all_results = {}
    for speed in speeds:
        print(f"\nBenchmarking {speed} m/s configurations...")
        try:
            all_results[speed] = run_benchmark(speed, outputs_base, out_dir, args.cpu)
        except FileNotFoundError as e:
            print(f"  ERROR: {e}")
            all_results[speed] = {"error": str(e)}

    summary_path = out_dir / "latency_summary.json"
    with open(summary_path, "w") as fh:
        json.dump(all_results, fh, indent=2)
    print(f"\nSummary saved to: {summary_path}")


if __name__ == "__main__":
    main()
