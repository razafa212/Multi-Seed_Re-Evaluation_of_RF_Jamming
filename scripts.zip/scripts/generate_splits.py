"""
generate_splits.py
==================
Generate and persist the fixed episode-split indices for all seeds and both
speed scenarios used in the Detector paper.

The split logic is taken VERBATIM from common.py / the original notebooks.
Running this script does NOT require the datasets to be present — it only
requires the pseudo_run_id column, which is derived from the raw CSV.

Usage
-----
  # With datasets available at default paths (Dataset_1.csv, Dataset_2.csv):
  python generate_splits.py

  # With custom dataset paths:
  DATASET_15=/path/to/Dataset_2.csv DATASET_25=/path/to/Dataset_1.csv python generate_splits.py

  # Output location (default: outputs/fixed_splits/):
  python generate_splits.py --out outputs/fixed_splits

Output files
------------
  outputs/fixed_splits/
    split_15ms_seed42.json
    split_15ms_seed123.json
    ...  (5 seeds × 2 speeds = 10 files)
    split_manifest.json     <- checksums + summary for audit trail

Each split_<speed>ms_seed<N>.json contains:
  {
    "seed": 42,
    "target_speed": 15,
    "n_episodes": {"train": X, "val": Y, "test": Z},
    "split": {
      "train": ["15.0_1_0", "15.0_2_1", ...],
      "val":   [...],
      "test":  [...]
    }
  }
"""

import os, json, hashlib, argparse
from pathlib import Path
from datetime import datetime, timezone

# ── Import shared pipeline ────────────────────────────────────────────────────
try:
    from common import load_dataset, split_by_episode, SEEDS
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from common import load_dataset, split_by_episode, SEEDS


def generate_split(target_speed: int, seed: int) -> dict:
    """Return a dict of {train, val, test} episode ID lists for one seed."""
    df = load_dataset(target_speed)
    train_df, val_df, test_df = split_by_episode(df, seed=seed)

    get_eps = lambda d: sorted(d['pseudo_run_id'].unique().tolist())
    train_eps = get_eps(train_df)
    val_eps   = get_eps(val_df)
    test_eps  = get_eps(test_df)

    return {
        "seed": seed,
        "target_speed": target_speed,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "n_episodes": {
            "total": len(train_eps) + len(val_eps) + len(test_eps),
            "train": len(train_eps),
            "val":   len(val_eps),
            "test":  len(test_eps),
        },
        "split": {
            "train": train_eps,
            "val":   val_eps,
            "test":  test_eps,
        }
    }


def sha256_of_dict(d: dict) -> str:
    raw = json.dumps(d, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(raw.encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description="Generate fixed split indices for all seeds.")
    parser.add_argument("--out", default="outputs/fixed_splits",
                        help="Output directory (default: outputs/fixed_splits)")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    speeds = [15, 25]
    manifest = {"generated_at": datetime.now(timezone.utc).isoformat(), "files": []}

    for speed in speeds:
        for seed in SEEDS:
            print(f"  Generating split: {speed} m/s, seed {seed} ...", end=" ", flush=True)
            split_data = generate_split(speed, seed)
            fname = f"split_{speed}ms_seed{seed}.json"
            fpath = out_dir / fname
            with open(fpath, "w") as fh:
                json.dump(split_data, fh, indent=2)

            checksum = sha256_of_dict(split_data["split"])
            manifest["files"].append({
                "file": fname,
                "speed": speed,
                "seed": seed,
                "n_test_episodes": split_data["n_episodes"]["test"],
                "sha256_of_split": checksum,
            })
            print(f"OK  (test episodes: {split_data['n_episodes']['test']})")

    manifest_path = out_dir / "split_manifest.json"
    with open(manifest_path, "w") as fh:
        json.dump(manifest, fh, indent=2)

    print(f"\nAll splits saved to: {out_dir}/")
    print(f"Manifest (with SHA-256 checksums): {manifest_path}")


if __name__ == "__main__":
    main()
