"""
reproduce_tables_figures.py
===========================
Regenerate every main table and figure in the Detector paper directly from
the per-seed JSON outputs stored in outputs/Detector_Results/.

No datasets or trained models are required — only the pre-computed output
files that ship with the reproducibility package.

Usage
-----
  python reproduce_tables_figures.py

  # Save figures to a custom directory:
  python reproduce_tables_figures.py --fig-dir outputs/figures

  # Print tables only (no figures):
  python reproduce_tables_figures.py --no-figures

Output
------
  outputs/figures/
    fig_accuracy_distribution.png    — per-seed accuracy box-plots (both speeds)
    fig_knn_sensitivity.png          — Table VI: k-NN sensitivity
    fig_confusion_matrix_15ms.png    — averaged confusion matrix, 15 m/s
    fig_confusion_matrix_25ms.png    — averaged confusion matrix, 25 m/s
    fig_ablation.png                 — ablation bar chart (Table V)
    fig_latency.png                  — Table VIII: latency comparison (if available)
  outputs/tables/
    table_IV_main_results.csv        — mean ± std accuracy for both speeds
    table_V_ablation.csv             — ablation results
    table_VI_knn_sensitivity.csv     — k-NN sensitivity
    table_VII_cross_speed.csv        — per-method per-seed results
    table_VIII_latency.csv           — latency + memory (if benchmark ran)
"""

import json, argparse
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns
    PLOT = True
except ImportError:
    PLOT = False
    print("[WARN] matplotlib/seaborn not available — skipping figure generation.")


# ── Helpers ───────────────────────────────────────────────────────────────────

SEEDS  = [42, 123, 456, 789, 2024]
SPEEDS = [15, 25]

def load_json(path: Path) -> dict:
    with open(path) as f:
        return json.load(f)

def pct(v):
    return v * 100 if v < 1.5 else v   # handle raw [0,1] or already-pct values

def mean_std(values):
    a = np.array(values, dtype=float)
    return a.mean(), (a.std(ddof=1) if len(a) > 1 else 0.0)


# ── Table IV — Main results (accuracy, precision, recall, F1) ─────────────────

def table_IV(results_dir: Path, out_dir: Path):
    rows = []
    for speed in SPEEDS:
        s = load_json(results_dir / f"seed_runs_{speed}ms" / "summary.json")
        rows.append({
            "Speed (m/s)":         speed,
            "Accuracy mean (%)":   round(s["accuracy_mean"], 2),
            "Accuracy std (%)":    round(s["accuracy_std"],  2),
            "Precision mean (%)":  round(s["precision_mean"], 2),
            "Precision std (%)":   round(s["precision_std"],  2),
            "Recall mean (%)":     round(s["recall_mean"],    2),
            "Recall std (%)":      round(s["recall_std"],     2),
            "F1 mean (%)":         round(s["f1_mean"],        2),
            "F1 std (%)":          round(s["f1_std"],         2),
        })
    df = pd.DataFrame(rows)
    out = out_dir / "table_IV_main_results.csv"
    df.to_csv(out, index=False)
    print("\n── Table IV  Main Results ──────────────────────────────────")
    print(df.to_string(index=False))
    print(f"Saved → {out}")
    return df


# ── Table V — Ablation ────────────────────────────────────────────────────────

def table_V(results_dir: Path, out_dir: Path):
    rows = []
    for speed in SPEEDS:
        abl = load_json(results_dir / f"seed_runs_{speed}ms" / "ablation_summary.json")
        for variant, stats in abl.items():
            if isinstance(stats, dict):
                # Actual format: {"mean": 91.56, "std": 3.24, "formatted": "91.56 ± 3.24"}
                mean_v = stats.get("mean") or stats.get("accuracy_mean")
                std_v  = stats.get("std")  or stats.get("accuracy_std", 0.0)
                if mean_v is not None:
                    rows.append({
                        "Speed (m/s)": speed,
                        "Variant":     variant,
                        "Acc mean (%)": round(float(mean_v), 2),
                        "Acc std (%)":  round(float(std_v),  2),
                        "Formatted":    stats.get("formatted", ""),
                    })
    if not rows:
        print("\n[WARN] Ablation summary format unrecognised — skipping Table V.")
        return None
    df = pd.DataFrame(rows)
    out = out_dir / "table_V_ablation.csv"
    df.to_csv(out, index=False)
    print("\n── Table V  Ablation ───────────────────────────────────────")
    print(df.to_string(index=False))
    print(f"Saved → {out}")
    return df


# ── Table VI — k-NN sensitivity ───────────────────────────────────────────────

def table_VI(results_dir: Path, out_dir: Path):
    rows = []
    for speed in SPEEDS:
        knn = load_json(results_dir / f"seed_runs_{speed}ms" / "knn_sensitivity_summary.json")
        for k_label, stats in sorted(knn.items()):
            if isinstance(stats, dict):
                # Format: {"accuracy_formatted": "91.28 ± 3.87", "density_formatted": ...}
                acc_fmt = stats.get("accuracy_formatted", "")
                if acc_fmt and "±" in acc_fmt:
                    parts = acc_fmt.split("±")
                    rows.append({
                        "Speed (m/s)":  speed,
                        "k":            k_label,
                        "Acc mean (%)": round(float(parts[0].strip()), 2),
                        "Acc std (%)":  round(float(parts[1].strip()), 2),
                        "Formatted":    acc_fmt,
                    })
    if not rows:
        # Fallback: read per-seed k-NN from individual seed results
        for speed in SPEEDS:
            per_seed = {}
            for seed in SEEDS:
                r = load_json(results_dir / f"seed_runs_{speed}ms" / f"seed_{seed}_result.json")
                knn = r.get("knn_sensitivity", {})
                for k_label, val in knn.items():
                    acc = val if not isinstance(val, dict) else val.get("accuracy", float("nan"))
                    per_seed.setdefault(k_label, []).append(float(acc))
            for k_label, accs in sorted(per_seed.items()):
                m, s = mean_std([pct(a) for a in accs])
                rows.append({"Speed (m/s)": speed, "k": k_label,
                             "Acc mean (%)": round(m, 2), "Acc std (%)": round(s, 2)})

    df = pd.DataFrame(rows)
    out = out_dir / "table_VI_knn_sensitivity.csv"
    df.to_csv(out, index=False)
    print("\n── Table VI  k-NN Sensitivity ──────────────────────────────")
    print(df.to_string(index=False))
    print(f"Saved → {out}")
    return df


# ── Table VII — Cross-speed per-method ────────────────────────────────────────

def table_VII(results_dir: Path, out_dir: Path):
    t7 = load_json(results_dir / "tabel_VII_final.json")
    rows = []
    method_map = {
        "detector_15": ("Detector", 15),
        "detector_25": ("Detector", 25),
        "rf_15":       ("RF-Stat",  15),
        "rf_25":       ("RF-Stat",  25),
        "lstm_15":     ("LSTM",     15),
        "lstm_25":     ("LSTM",     25),
        "bert_15":     ("BERT-WP",  15),
        "bert_25":     ("BERT-WP",  25),
    }
    for key, vals in t7.items():
        if key not in method_map:
            continue
        method, speed = method_map[key]
        accs = [pct(v) for v in vals]
        m, s = mean_std(accs)
        row = {"Method": method, "Speed (m/s)": speed, "Mean Acc (%)": round(m, 2), "Std (%)": round(s, 2)}
        for i, (seed, acc) in enumerate(zip(SEEDS, accs)):
            row[f"seed{seed}"] = round(acc, 2)
        rows.append(row)

    df = pd.DataFrame(rows).sort_values(["Speed (m/s)", "Method"])
    out = out_dir / "table_VII_cross_speed.csv"
    df.to_csv(out, index=False)
    print("\n── Table VII  Per-Method Per-Seed ──────────────────────────")
    print(df.to_string(index=False))
    print(f"Saved → {out}")
    return df


# ── Table VIII — Latency (if available) ───────────────────────────────────────

def table_VIII(results_dir: Path, out_dir: Path):
    rows = []
    for speed in SPEEDS:
        bench_path = results_dir / f"complexity_benchmark_v3_{speed}ms.json"
        if not bench_path.exists():
            continue
        bench = load_json(bench_path)
        hw = bench.get("hardware", {})
        for cfg_name, cfg in bench.get("configurations", {}).items():
            lat = cfg.get("latency_ms") or cfg.get("latency_pure_ms") or {}
            rows.append({
                "Speed (m/s)": speed,
                "Config":      cfg.get("config_name", cfg_name),
                "Target tier": cfg.get("target_tier", "—"),
                "Latency mean (ms)": round(lat.get("mean_ms", float("nan")), 2),
                "Latency p95 (ms)":  round(lat.get("p95_ms", float("nan")), 2),
                "GPU peak (MB)":     round(cfg.get("memory_mb", {}).get("gpu_peak_mb", float("nan")), 2),
                "CPU peak (MB)":     round(cfg.get("memory_mb", {}).get("cpu_peak_mb", float("nan")), 4),
                "Hardware":          hw.get("gpu_name", hw.get("platform", "—")),
            })
    if not rows:
        print("\n[WARN] No latency benchmark files found. Run benchmark_latency.py first.")
        return None
    df = pd.DataFrame(rows)
    out = out_dir / "table_VIII_latency.csv"
    df.to_csv(out, index=False)
    print("\n── Table VIII  Latency & Complexity ────────────────────────")
    print(df.to_string(index=False))
    print(f"Saved → {out}")
    return df


# ── Figures ───────────────────────────────────────────────────────────────────

def figure_accuracy_distribution(results_dir: Path, fig_dir: Path):
    if not PLOT:
        return
    data = {}
    for speed in SPEEDS:
        s = load_json(results_dir / f"seed_runs_{speed}ms" / "summary.json")
        data[f"{speed} m/s"] = [pct(a) for a in s["raw_accuracies"]]

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.boxplot(list(data.values()), labels=list(data.keys()), patch_artist=True)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Detector — per-seed accuracy distribution (5 seeds)")
    ax.set_ylim(50, 105)
    ax.grid(axis="y", alpha=0.4)
    fig.tight_layout()
    out = fig_dir / "fig_accuracy_distribution.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"Figure saved → {out}")


def figure_knn_sensitivity(results_dir: Path, fig_dir: Path):
    if not PLOT:
        return
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    for ax, speed in zip(axes, SPEEDS):
        k_vals, means, stds = [], [], []
        knn = load_json(results_dir / f"seed_runs_{speed}ms" / "knn_sensitivity_summary.json")
        for k_label, stats in sorted(knn.items()):
            if isinstance(stats, dict) and "accuracy_mean" in stats:
                k_vals.append(k_label)
                means.append(stats["accuracy_mean"])
                stds.append(stats.get("accuracy_std", 0.0))
        if k_vals:
            ax.errorbar(k_vals, means, yerr=stds, marker="o", capsize=4)
        ax.set_title(f"{speed} m/s")
        ax.set_xlabel("k")
        ax.set_ylabel("Accuracy (%)")
        ax.grid(alpha=0.4)
    fig.suptitle("k-NN Sensitivity (Table VI)")
    fig.tight_layout()
    out = fig_dir / "fig_knn_sensitivity.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"Figure saved → {out}")


def figure_confusion_matrices(results_dir: Path, fig_dir: Path):
    if not PLOT:
        return
    classes = ["Interference", "Reactive", "Constant"]
    for speed in SPEEDS:
        cms = []
        for seed in SEEDS:
            r = load_json(results_dir / f"seed_runs_{speed}ms" / f"seed_{seed}_result.json")
            cms.append(np.array(r["confusion_matrix"]))
        avg_cm = np.mean(cms, axis=0)
        norm_cm = avg_cm / avg_cm.sum(axis=1, keepdims=True)

        fig, ax = plt.subplots(figsize=(5, 4))
        sns.heatmap(norm_cm, annot=True, fmt=".2f", cmap="Blues",
                    xticklabels=classes, yticklabels=classes, ax=ax)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_title(f"Confusion Matrix — {speed} m/s (5-seed avg, normalised)")
        fig.tight_layout()
        out = fig_dir / f"fig_confusion_matrix_{speed}ms.png"
        fig.savefig(out, dpi=150)
        plt.close(fig)
        print(f"Figure saved → {out}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Reproduce all main tables and figures from stored per-seed outputs.")
    parser.add_argument("--outputs",     default="outputs/Detector_Results",
                        help="Path to Detector_Results directory")
    parser.add_argument("--tables-dir",  default="outputs/tables")
    parser.add_argument("--fig-dir",     default="outputs/figures")
    parser.add_argument("--no-figures",  action="store_true")
    args = parser.parse_args()

    results_dir = Path(args.outputs)
    tables_dir  = Path(args.tables_dir)
    fig_dir     = Path(args.fig_dir)

    tables_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_figures:
        fig_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("Detector Paper — Reproducing Tables & Figures")
    print(f"  results_dir : {results_dir.resolve()}")
    print(f"  tables_dir  : {tables_dir.resolve()}")
    print("=" * 60)

    table_IV(results_dir, tables_dir)
    table_V(results_dir, tables_dir)
    table_VI(results_dir, tables_dir)
    table_VII(results_dir, tables_dir)
    table_VIII(results_dir, tables_dir)

    if not args.no_figures and PLOT:
        print("\n── Generating Figures ──────────────────────────────────────")
        figure_accuracy_distribution(results_dir, fig_dir)
        figure_knn_sensitivity(results_dir, fig_dir)
        figure_confusion_matrices(results_dir, fig_dir)

    print("\nDone.")


if __name__ == "__main__":
    main()
