#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────
# reproduce_all.sh — End-to-end reproduction from raw dataset to
#                    every table and figure in the manuscript.
#
# Prerequisites:
#   1. Python 3.10+  with packages from requirements.txt installed
#   2. Raw dataset CSVs:
#        Dataset_1.csv  (25 m/s)
#        Dataset_2.csv  (15 m/s)
#      from: Kosmanos et al., "RF Jamming Dataset for Vehicular
#      Wireless Networks" — https://doi.org/10.5281/zenodo.XXXXXXX
#   3. GPU runtime recommended (T4 or better) for LSTM/BERT training
#
# Usage:
#   bash scripts/reproduce_all.sh path/to/Dataset_1.csv path/to/Dataset_2.csv
#
# The script is idempotent; re-running overwrites previous outputs.
# ──────────────────────────────────────────────────────────────────
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: $0 <Dataset_1.csv> <Dataset_2.csv>"
  echo "  Dataset_1.csv = 25 m/s regime"
  echo "  Dataset_2.csv = 15 m/s regime"
  exit 1
fi

DS25="$1"
DS15="$2"
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "============================================================"
echo "  Reproduction Script"
echo "  Dataset 25 m/s: $DS25"
echo "  Dataset 15 m/s: $DS15"
echo "  Repo root:      $REPO_ROOT"
echo "============================================================"

export DATASET_25="$DS25"
export DATASET_15="$DS15"

# ── Step 1: Export split indices ──────────────────────────────────
echo ""
echo "[Step 1/4] Exporting split indices for all seeds..."
python "$REPO_ROOT/scripts/export_split_indices.py" \
    --dataset-25 "$DS25" \
    --dataset-15 "$DS15" \
    --outdir "$REPO_ROOT/split_indices"

# ── Step 2: Verify preprocessing determinism ─────────────────────
echo ""
echo "[Step 2/4] Running preprocessing pipeline (all seeds)..."
python "$REPO_ROOT/scripts/preprocess_dataset.py" \
    --dataset-25 "$DS25" \
    --dataset-15 "$DS15" \
    --all-seeds \
    --save-arrays

# ── Step 3: Main detector notebooks ─────────────────────────────
echo ""
echo "[Step 3/4] Main detector notebooks..."
echo "  These must be run interactively in Google Colab with GPU:"
echo ""
echo "  a) notebooks/Detector_25ms_FINAL.ipynb"
echo "     → Tables IV, V, VI (25 m/s), Table VIII (latency benchmark)"
echo "     → outputs/seed_runs_25ms/*.json"
echo ""
echo "  b) notebooks/Detector_15ms_FINAL.ipynb"
echo "     → Tables IV, V, VI (15 m/s)"
echo "     → outputs/seed_runs_15ms/*.json"
echo ""
echo "  c) notebooks/Detector_BERT_FINAL.ipynb"
echo "     → Table VII (BERT WordPiece baseline)"
echo "     → outputs/baselines_*/bert_wp_*.json"
echo ""
echo "  d) notebooks/Extra1_Cohens_D_Analysis.ipynb"
echo "     → Table VI supplementary (Cohen's d effect sizes)"
echo ""
echo "  e) notebooks/Extra2_Ablation_Paired_Test.ipynb"
echo "     → Table V supplementary (paired t-tests)"
echo ""

# ── Step 4: Revision experiment notebooks ────────────────────────
echo "[Step 4/4] Revision experiment notebooks:"
echo ""
echo "  f) notebooks/T1_Leakage_GapSplit.ipynb"
echo "     → Section 4.7 (leakage audit, gap-split protocol)"
echo ""
echo "  g) notebooks/T2_Ablation_Features.ipynb"
echo "     → Table XI (feature ablation with paired tests)"
echo ""
echo "  h) notebooks/T3_LSTM_Sensitivity.ipynb"
echo "     → Table XII (LSTM activation/callback sensitivity)"
echo ""
echo "============================================================"
echo "  Steps 1-2 completed successfully."
echo "  Steps 3-4 require interactive Colab execution."
echo "  Pre-computed outputs are in outputs/ for verification."
echo "============================================================"
