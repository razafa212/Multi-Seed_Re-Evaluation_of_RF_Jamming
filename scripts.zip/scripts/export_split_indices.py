#!/usr/bin/env python3
"""
export_split_indices.py — Export train/val/test episode IDs for every seed.

Generates one JSON file per (seed, speed) pair in split_indices/, containing
the exact pseudo_run_id lists used by split_by_episode() in common.py.

Usage:
    python scripts/export_split_indices.py \
        --dataset-25 path/to/Dataset_1.csv \
        --dataset-15 path/to/Dataset_2.csv \
        --outdir split_indices

Output example (split_indices/split_seed42_25ms.json):
    {
        "seed": 42,
        "speed_regime": "25ms",
        "train_ratio": 0.6,
        "val_ratio": 0.2,
        "n_episodes": {"train": 7, "val": 2, "test": 3},
        "train_episodes": ["25.0_1_0", ...],
        "val_episodes":   ["25.0_2_1", ...],
        "test_episodes":  ["25.0_3_2", ...]
    }
"""
import os, sys, json, argparse

# Allow import of common.py from parent directory
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import common


def export_splits(dataset_25_path, dataset_15_path, outdir):
    os.makedirs(outdir, exist_ok=True)

    configs = [
        (25, dataset_25_path, 'ms'),
        (15, dataset_15_path, 'ms'),
    ]

    for target_speed, ds_path, suffix in configs:
        print(f"Loading {target_speed} m/s dataset from: {ds_path}")
        df = common.load_dataset(target_speed, path=ds_path)
        all_episodes = sorted(df['pseudo_run_id'].unique().tolist())
        print(f"  Total pseudo-episodes: {len(all_episodes)}")

        for seed in common.SEEDS:
            train_df, val_df, test_df = common.split_by_episode(
                df, train_ratio=0.6, val_ratio=0.2, seed=seed
            )

            train_eps = sorted(train_df['pseudo_run_id'].unique().tolist())
            val_eps   = sorted(val_df['pseudo_run_id'].unique().tolist())
            test_eps  = sorted(test_df['pseudo_run_id'].unique().tolist())

            record = {
                "seed": seed,
                "speed_regime": f"{target_speed}{suffix}",
                "train_ratio": 0.6,
                "val_ratio": 0.2,
                "all_episodes": all_episodes,
                "n_episodes": {
                    "total": len(all_episodes),
                    "train": len(train_eps),
                    "val":   len(val_eps),
                    "test":  len(test_eps),
                },
                "train_episodes": train_eps,
                "val_episodes":   val_eps,
                "test_episodes":  test_eps,
            }

            fname = f"split_seed{seed}_{target_speed}ms.json"
            fpath = os.path.join(outdir, fname)
            with open(fpath, 'w') as f:
                json.dump(record, f, indent=2)
            print(f"  [seed={seed}] train={len(train_eps)}, "
                  f"val={len(val_eps)}, test={len(test_eps)} -> {fname}")

    print(f"\nAll split indices saved to: {outdir}/")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Export per-seed train/val/test episode split indices."
    )
    parser.add_argument('--dataset-25', required=True,
                        help='Path to Dataset_1.csv (25 m/s)')
    parser.add_argument('--dataset-15', required=True,
                        help='Path to Dataset_2.csv (15 m/s)')
    parser.add_argument('--outdir', default='split_indices',
                        help='Output directory (default: split_indices)')
    args = parser.parse_args()
    export_splits(args.dataset_25, args.dataset_15, args.outdir)
