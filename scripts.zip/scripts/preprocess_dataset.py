#!/usr/bin/env python3
"""
preprocess_dataset.py — Convert raw Kosmanos et al. CSV into windowed arrays.

Demonstrates the full preprocessing pipeline used by the main detector
notebooks: load → filter speed band → build pseudo_run_id → episode-based
split → windowing → padding → normalisation → tabular feature extraction.

This script does NOT train any model. It verifies that preprocessing
produces deterministic outputs for a given seed, and optionally saves
the intermediate arrays to disk for inspection.

Usage:
    python scripts/preprocess_dataset.py \
        --dataset-25 path/to/Dataset_1.csv \
        --dataset-15 path/to/Dataset_2.csv \
        --seed 42 \
        --save-arrays

Output (when --save-arrays):
    preprocessed/seed42_25ms_X_train.npy
    preprocessed/seed42_25ms_y_train.npy
    preprocessed/seed42_25ms_X_tabular_train.npy
    ... (val, test sets likewise)
"""
import os, sys, argparse
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import common


def preprocess_one(target_speed, ds_path, seed, save_dir=None):
    print(f"\n{'='*60}")
    print(f"  Preprocessing {target_speed} m/s  |  seed={seed}")
    print(f"{'='*60}")

    common.set_all_seeds(seed)
    df = common.load_dataset(target_speed, path=ds_path)
    print(f"  Rows after speed filter: {len(df)}")

    # Episode split
    train_df, val_df, test_df = common.split_by_episode(
        df, train_ratio=0.6, val_ratio=0.2, seed=seed
    )
    print(f"  Episodes: train={train_df['pseudo_run_id'].nunique()}, "
          f"val={val_df['pseudo_run_id'].nunique()}, "
          f"test={test_df['pseudo_run_id'].nunique()}")

    # Windowing (15-second non-overlapping)
    Xtr_list, ytr, _ = common.create_windows(train_df, common.WINDOW_SEC)
    Xva_list, yva, _ = common.create_windows(val_df,   common.WINDOW_SEC)
    Xte_list, yte, _ = common.create_windows(test_df,  common.WINDOW_SEC)
    print(f"  Windows (15s): train={len(Xtr_list)}, "
          f"val={len(Xva_list)}, test={len(Xte_list)}")

    # Pad + normalise
    Xtr, Xva, Xte, max_len = common.pad_and_normalize(
        Xtr_list, Xva_list, Xte_list
    )
    print(f"  Padded shape: ({Xtr.shape[0]}, {max_len}, {Xtr.shape[2]})")

    # Tabular features (35-dim)
    Xtr_tab = common.extract_tabular_features(Xtr)
    Xva_tab = common.extract_tabular_features(Xva)
    Xte_tab = common.extract_tabular_features(Xte)
    print(f"  Tabular dims: {Xtr_tab.shape[1]}")

    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        tag = f"seed{seed}_{target_speed}ms"
        for name, arr in [
            (f"{tag}_X_train", Xtr), (f"{tag}_y_train", ytr),
            (f"{tag}_X_val",   Xva), (f"{tag}_y_val",   yva),
            (f"{tag}_X_test",  Xte), (f"{tag}_y_test",  yte),
            (f"{tag}_X_tabular_train", Xtr_tab),
            (f"{tag}_X_tabular_val",   Xva_tab),
            (f"{tag}_X_tabular_test",  Xte_tab),
        ]:
            np.save(os.path.join(save_dir, name + ".npy"), arr)
        print(f"  Arrays saved to {save_dir}/{tag}_*.npy")

    return Xtr, ytr, Xva, yva, Xte, yte


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Run preprocessing pipeline and optionally save arrays."
    )
    parser.add_argument('--dataset-25', required=True)
    parser.add_argument('--dataset-15', required=True)
    parser.add_argument('--seed', type=int, default=42,
                        help='Seed for episode split (default: 42)')
    parser.add_argument('--all-seeds', action='store_true',
                        help='Run for all 5 seeds: 42, 123, 456, 789, 2024')
    parser.add_argument('--save-arrays', action='store_true',
                        help='Save .npy arrays to preprocessed/')
    args = parser.parse_args()

    seeds = common.SEEDS if args.all_seeds else [args.seed]
    save_dir = 'preprocessed' if args.save_arrays else None

    for seed in seeds:
        for speed, path in [(25, args.dataset_25), (15, args.dataset_15)]:
            preprocess_one(speed, path, seed, save_dir)

    print("\nDone.")
